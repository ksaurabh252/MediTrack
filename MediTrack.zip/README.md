# MediTrack - Prescription and Medication Management Tool

MediTrack is a modern, responsive web application designed to help users effortlessly manage their medications. It focuses on providing timely reminders, simplifying prescription renewals, and offering a clear history of medication usage, ultimately enhancing patient adherence and improving health outcomes.

## Project Structure

meditrack/
├── public/ # Static files
│ ├── index.html
│ ├── manifest.json # PWA config
│ ├── robots.txt
│ └── assets/ # Favicons, static images
│ ├── icons/
│ └── logos/
│
├── src/
│ ├── api/ # API services
│ │ ├── auth.js # Auth API calls
│ │ ├── medications.js # Medication CRUD
│ │ └── prescriptions.js # Prescription API
│ │
│ ├── assets/ # Dynamic assets
│ │ ├── fonts/
│ │
│ │ └── styles/
│ │ ├── base/ # Global styles
│ │ ├── components/ # Component-specific CSS
│ │ └── themes/ # Light/dark mode
│ │
│ ├── components/ # Reusable UI components
│ │ ├── ui/
│ │ │ ├── Button/
│ │ │ ├── Card/
│ │ │ └── Modal/
│ │ │
│ │ ├── dashboard/
│ │ │ ├── MedicationCard.jsx
│ │ │ └── StatsWidget.jsx
│ │ │
│ │ ├── medications/
│ │ │ ├── DoseReminder.jsx
│ │ │ └── SchedulePicker.jsx
│ │ │
│ │ └── notifications/
│ │ ├── AlertBanner.jsx
│ │ └── Toast.jsx
│ │ |\_\_FileUpload.jsx for fileUpload
| |
│ ├── config/ # App configuration
│ │ ├── routes.js # All route paths
│ │ └── constants.js # App-wide constants
│ │
│ ├── contexts/ # React contexts
│ │ ├── AuthContext.jsx
│ │ └── MedicationContext.jsx
│ │
│ ├── hooks/ # Custom hooks
│ │ ├── useMedications.js
│ │ └── useNotifications.js
│ │
│ ├── layouts/ # Page layouts
│ │ ├── MainLayout.jsx # Default (with sidebar)
│ │ └── AuthLayout.jsx # Login/signup pages
│ │
│ ├── pages/ # Route-based pages
│ │ ├── Dashboard/
│ │ ├── Medications/
│ │ │ ├── AddMedication.jsx
│ │ │ └── MedicationList.jsx
│ │ ├── Prescriptions/
│ │ ├── Profile/
│ │ └── Auth/
│ │ ├── Login.jsx
│ │ └── Register.jsx
│ │
│ ├── store/ # Redux store
│ │ ├── slices/
│ │ │ ├── authSlice.js
│ │ │ └── medsSlice.js
│ │ └── store.js
│ │
│ ├── utils/ # Helper functions
│ │ ├── dateUtils.js # Date formatting
│ │ ├── notificationUtils.js
│ │ └── validation.js # Form validations
│ │
│ ├── App.jsx # Root component
│ ├── index.jsx # Entry point
│ └── serviceWorker.js # PWA setup
│
├── .env # Environment variables
├── .env.development
├── .eslintrc # Linting rules
├── .gitignore
├── package.json
└── README.md # Project documentation
